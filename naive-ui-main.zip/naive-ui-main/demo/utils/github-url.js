export const repoUrl = 'https://github.com/tusen-ai/naive-ui'
export const blobUrl = repoUrl + '/blob/main/'
