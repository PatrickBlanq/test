<template>
  <vue-3 />
</template>

<script>
import Vue3 from '../../../../../vue3.md'

export default {
  components: {
    Vue3
  }
}
</script>
