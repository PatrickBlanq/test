# Create Themed Component

You may not want to use only the provided components and want to write themed components.

Naive UI provides some tools for developers to create themed components easier.

## Demos

```demo
provide-theme
element
use-theme-vars
```
