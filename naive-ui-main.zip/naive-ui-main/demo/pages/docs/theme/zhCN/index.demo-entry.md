# 创建适配主题的组件

你可能觉得只用内置的组件不够爽，想自己也写适配主题的组件。

Naive UI 提供一些工具帮助开发者简单的创建支持主题的组件。

## 演示

```demo
provide-theme
element
use-theme-vars
```
