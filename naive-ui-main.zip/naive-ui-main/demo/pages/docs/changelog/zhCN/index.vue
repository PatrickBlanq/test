<template>
  <changelog />
</template>

<script>
import Changelog from '../../../../../CHANGELOG.zh-CN.md'

export default {
  components: {
    Changelog
  }
}
</script>
