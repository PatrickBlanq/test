<template>
  <changelog />
</template>

<script>
import Changelog from '../../../../../CHANGELOG.en-US.md'

export default {
  components: {
    Changelog
  }
}
</script>
