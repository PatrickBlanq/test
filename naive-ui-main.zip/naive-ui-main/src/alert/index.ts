export { default as NAlert, alertProps } from './src/Alert'
export type { AlertProps } from './src/Alert'
