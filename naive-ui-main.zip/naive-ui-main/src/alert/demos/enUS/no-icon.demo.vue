<markdown>
# No icon
</markdown>

<template>
  <n-alert :show-icon="false">
    Yeah I'm back in the U.S.S.R.<br>
    You don't know how lucky you are boys
  </n-alert>
</template>
