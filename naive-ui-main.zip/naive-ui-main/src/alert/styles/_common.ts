export default {
  iconMargin: '11px 8px 0 12px',
  iconMarginRtl: '11px 12px 0 8px',
  iconSize: '24px',
  closeIconSize: '16px',
  closeSize: '20px',
  closeMargin: '13px 14px 0 0',
  closeMarginRtl: '13px 0 0 14px',
  padding: '13px'
}
