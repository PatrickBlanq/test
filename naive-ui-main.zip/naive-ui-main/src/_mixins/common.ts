export const cssrAnchorMetaName = 'naive-ui-style'
