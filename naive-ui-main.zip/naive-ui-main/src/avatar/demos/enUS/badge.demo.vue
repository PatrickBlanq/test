<markdown>
# Badge

Using it with `badge` would be nice (if you like tons of notifications).
</markdown>

<template>
  <n-badge value="999+">
    <n-avatar>App</n-avatar>
  </n-badge>
</template>
