<markdown>
# Color

You can set colors related to things you want to eat.
</markdown>

<template>
  <n-avatar
    :style="{
      color: 'yellow',
      backgroundColor: 'red'
    }"
  >
    M
  </n-avatar>
</template>
