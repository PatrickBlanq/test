<markdown>
# 颜色

你可以把它设成某种和你爱吃的东西有关的颜色。
</markdown>

<template>
  <n-avatar
    :style="{
      color: 'yellow',
      backgroundColor: 'red'
    }"
  >
    M
  </n-avatar>
</template>
