<markdown>
# 加载失败时显示的图像

下面的头像加载失败时会展示 07akioni。
</markdown>

<template>
  <n-avatar
    round
    size="small"
    src="empty.png"
    fallback-src="https://07akioni.oss-cn-beijing.aliyuncs.com/07akioni.jpeg"
  />
</template>
