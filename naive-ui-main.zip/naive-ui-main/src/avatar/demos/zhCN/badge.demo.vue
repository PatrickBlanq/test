<markdown>
# 标记

和 `Badge` 一起用也挺好的 (如果你喜欢看到一堆一堆的推送)。
</markdown>

<template>
  <n-badge value="999+">
    <n-avatar>App</n-avatar>
  </n-badge>
</template>
