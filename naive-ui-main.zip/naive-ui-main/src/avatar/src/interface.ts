export type Size = number | 'small' | 'medium' | 'large'
export type ObjectFit = 'fill' | 'contain' | 'cover' | 'none' | 'scale-down'
