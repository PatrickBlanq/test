export { default as NAvatar, avatarProps } from './src/Avatar'
export type { AvatarProps } from './src/Avatar'
