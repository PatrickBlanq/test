export { default as avatarDark } from './dark'
export { default as avatarLight } from './light'
export type { AvatarThemeVars, AvatarTheme } from './light'
