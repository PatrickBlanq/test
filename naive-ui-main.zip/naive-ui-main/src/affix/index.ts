export { default as NAffix, affixProps } from './src/Affix'
export type { AffixProps } from './src/Affix'
