export { isDocument } from './is-document'
export { download } from './download'
