export const isBrowser =
  typeof document !== 'undefined' && typeof window !== 'undefined'
