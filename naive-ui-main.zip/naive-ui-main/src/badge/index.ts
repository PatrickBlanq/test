export { default as NBadge, badgeProps } from './src/Badge'
export type { BadgeProps } from './src/Badge'
