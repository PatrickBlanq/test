<markdown>
# Customizing color
</markdown>

<template>
  <n-badge value="15" color="grey">
    <n-avatar />
  </n-badge>
</template>
