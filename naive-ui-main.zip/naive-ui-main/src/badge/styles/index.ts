export { default as badgeDark } from './dark'
export { default as badgeLight } from './light'
export { badgeRtl } from './rtl'
export type { BadgeTheme, BadgeThemeVars } from './light'
