export { default as commonDark } from './dark'
export { default as commonLight } from './light'
export type { ThemeCommonVars } from './light'
