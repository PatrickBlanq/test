export { default as NAnchor, anchorProps } from './src/AnchorAdapter'
export type { AnchorInst, AnchorProps } from './src/AnchorAdapter'
export { default as NAnchorLink, anchorLinkProps } from './src/Link'
export type { AnchorLinkProps } from './src/Link'
