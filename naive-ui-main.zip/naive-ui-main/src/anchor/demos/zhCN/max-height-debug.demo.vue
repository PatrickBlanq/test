<markdown>
# 高度限定
</markdown>

<template>
  <div style="position: fixed; right: 0; top: 500px; z-index: 9">
    <n-anchor
      :bound="16"
      type="block"
      style="width: 128px; max-height: 100px"
      internal-scrollable
    >
      <n-anchor-link title="非常长的 TOC, 固定" href="#basic" />
      <n-anchor-link title="很长很长" href="#basic" />

      <n-anchor-link title="长到放不下" href="#ignore-gap" />
      <n-anchor-link title="长到放不下" href="#ignore-gap" />
      <n-anchor-link title="长到放不下" href="#ignore-gap" />
      <n-anchor-link title="长到放不下" href="#ignore-gap" />
      <n-anchor-link title="长到放不下" href="#ignore-gap" />
      <n-anchor-link title="长到放不下" href="#ignore-gap" />
      <n-anchor-link title="长到放不下" href="#ignore-gap" />
      <n-anchor-link title="长到放不下" href="#ignore-gap" />
      <n-anchor-link title="长到放不下" href="#ignore-gap" />
      <n-anchor-link title="长到放不下" href="#ignore-gap" />
      <n-anchor-link title="长到放不下" href="#ignore-gap" />
      <n-anchor-link title="长到放不下" href="#ignore-gap" />
      <n-anchor-link title="长到放不下" href="#ignore-gap" />
      <n-anchor-link title="长到放不下" href="#ignore-gap" />
    </n-anchor>
  </div>
</template>
