export default {
  linkFontSize: '13px',
  linkPadding: '0 0 0 16px',
  railWidth: '4px'
}
