export default {
  width: '44px',
  height: '44px',
  borderRadius: '22px',
  iconSize: '26px'
}
