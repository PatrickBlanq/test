<markdown>
# 基础用法

BackTop 会找到首个可滚动的祖先元素并且监听它的滚动事件。
</markdown>

<template>
  <n-back-top :right="100" />
</template>
