<markdown>
# 改变位置

例如：right 40px & bottom 160px。
</markdown>

<template>
  <n-back-top :right="40" :bottom="160">
    <div
      style="
        width: 200px;
        height: 40px;
        line-height: 40px;
        text-align: center;
        font-size: 14px;
      "
    >
      改变位置
    </div>
  </n-back-top>
</template>
