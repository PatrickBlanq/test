<markdown>
# Basic

BackTop will find its first scrollable ascendant element and listen scroll event on it.
</markdown>

<template>
  <n-back-top :right="100" />
</template>
