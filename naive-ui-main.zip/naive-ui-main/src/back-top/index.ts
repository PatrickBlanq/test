export { default as NBackTop, backTopProps } from './src/BackTop'
export type { BackTopProps } from './src/BackTop'
