export { default as avatarGroupDark } from './dark'
export { default as avatarGroupLight } from './light'
export { avatarGroupRtl } from './rtl'
export type { AvatarGroupTheme, AvatarGroupThemeVars } from './light'
