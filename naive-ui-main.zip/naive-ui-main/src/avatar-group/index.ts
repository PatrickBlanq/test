export { default as NAvatarGroup, avatarGroupProps } from './src/AvatarGroup'
export type { AvatarGroupProps, AvatarGroupOption } from './src/AvatarGroup'
