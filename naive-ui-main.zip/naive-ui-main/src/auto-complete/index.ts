export { default as NAutoComplete, autoCompleteProps } from './src/AutoComplete'
export type { AutoCompleteProps } from './src/AutoComplete'
export type {
  AutoCompleteOption,
  AutoCompleteGroupOption,
  AutoCompleteInst
} from './src/interface'
