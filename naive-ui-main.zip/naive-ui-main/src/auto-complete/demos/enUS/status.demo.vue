<markdown>
# Validation status

Validation status can be applied outside form.
</markdown>

<template>
  <n-space vertical>
    <n-auto-complete status="warning" placeholder="" />
    <n-auto-complete status="error" placeholder="" />
  </n-space>
</template>
