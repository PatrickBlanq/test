<markdown>
# 验证状态

输入的验证状态可以脱离表单使用。
</markdown>

<template>
  <n-space vertical>
    <n-auto-complete status="warning" placeholder="" />
    <n-auto-complete status="error" placeholder="" />
  </n-space>
</template>
