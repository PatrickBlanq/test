export { default } from './src/FadeInExpandTransition'
