export { default } from './src/Clear'
