export default {
  paddingSingle: '0 26px 0 12px',
  paddingMultiple: '3px 26px 0 12px',
  clearSize: '16px',
  arrowSize: '16px'
}
