export { default } from './src/Selection'
export type { InternalSelectionInst } from './src/Selection'
