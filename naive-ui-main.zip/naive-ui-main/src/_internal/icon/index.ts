export { default as NBaseIcon } from './src/Icon'
