Themeable components:

- selection
- select-menu
- clear
