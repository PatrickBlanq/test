export { default } from './src/Wave'
export type { BaseWaveRef } from './src/Wave'
