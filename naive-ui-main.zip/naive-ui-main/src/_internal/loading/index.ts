export { default } from './src/Loading'
export type { BaseLoadingExposedProps } from './src/Loading'
