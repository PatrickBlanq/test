export { default } from './src/SlotMachine'
