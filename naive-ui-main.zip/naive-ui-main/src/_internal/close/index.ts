export { default as NBaseClose } from './src/Close'
