export { default } from './src/Suffix'
