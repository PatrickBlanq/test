export { default } from './src/IconSwitchTransition'
