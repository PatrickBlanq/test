import { mount } from '@vue/test-utils'
import { NScrollbar } from '../index'

describe('n-scrollbar', () => {
  it('should work with import on demand', () => {
    mount(NScrollbar)
  })
})
