export const commonVars = {
  railInsetHorizontal: 'auto 2px 4px 2px',
  railInsetVertical: '2px 4px 2px auto',
  railColor: 'transparent'
}
