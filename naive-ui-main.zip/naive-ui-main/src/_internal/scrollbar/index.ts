export {
  default as NScrollbar,
  XScrollbar as NxScrollbar
} from './src/Scrollbar'
export type { ScrollbarInst, ScrollbarProps } from './src/Scrollbar'
