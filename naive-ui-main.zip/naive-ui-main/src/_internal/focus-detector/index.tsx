import FocusDetector from './src/FocusDetector'

export default FocusDetector
