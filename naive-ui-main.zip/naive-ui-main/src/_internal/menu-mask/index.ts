export { default } from './src/MenuMask'
export type { MenuMaskRef } from './src/interface'
