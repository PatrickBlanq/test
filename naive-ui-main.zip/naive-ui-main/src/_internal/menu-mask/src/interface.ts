export interface MenuMaskRef {
  showOnce: (message: string, duration?: number) => void
}
