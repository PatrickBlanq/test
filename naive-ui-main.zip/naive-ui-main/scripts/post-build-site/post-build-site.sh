cp site/index.html site/404.html

rm -rf node_modules/naive-ui
