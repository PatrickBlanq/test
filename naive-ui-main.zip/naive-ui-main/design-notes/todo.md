# TODO

## Urgent

- message fullscreen
- use resolve slot!!!
- manual trigger style

## DataTable

## Form

- (easy) message support render function

## Popover

## Radio

- (easy) Button custom align & width

## Select

## Tabs

- (moderate) Left, right tabs

## Tree

- (moderate) Use set to check if node is checked or selected internally

## TreeSelect

- (moderate) Async

## DatePicker

- Do not allow start > end
