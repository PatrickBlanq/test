## Color

--color --color-hover --color-pressed --color-active --color-active-hover --color-active-pressed --color-focus --color-focus-hover --color-focus-active --color-focus-pressed --color-disabled --color-disabled-active

disabled-active > disabled > active-hover > active > pressed > hover > default
