You need to install `webpack` & `webpack-cli` globally.

```
./pre-build.sh
./build.sh

node dist/server.js

# browse localhost:8086
```
