webpack ./client.js --mode=development --output-filename=client.js
webpack --config ./webpack.config.server.js