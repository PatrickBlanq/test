# make sure cwd is the sh's dir

cd ./../../

./scripts/pre-build-site/pre-build-site.sh
