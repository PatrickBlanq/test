const tinyColor = require('tinycolor2')

const red = tinyColor('#ce347c').getBrightness()
const green = tinyColor('#00c060').getBrightness()
const orange = tinyColor('#EF8745').getBrightness()
const blue = tinyColor('#2090f0').getBrightness()
console.log(red, green, orange, blue)
